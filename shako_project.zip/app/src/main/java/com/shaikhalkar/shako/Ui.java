package com.shaikhalkar.shako;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(9,10,15);
    static final int SURFACE = Color.rgb(20,23,32);
    static final int BLUE = Color.rgb(93,124,255);
    static final int GOLD = Color.rgb(217,184,102);
    static final int TEXT = Color.rgb(245,247,255);
    static final int MUTED = Color.rgb(164,169,184);

    static int dp(Context c, int v) { return (int)(v * c.getResources().getDisplayMetrics().density + .5f); }

    static GradientDrawable rounded(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, (int) radiusDp));
        return g;
    }

    static TextView title(Context c, String s, float size) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextColor(TEXT); t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.RIGHT);
        return t;
    }

    static TextView body(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextColor(MUTED); t.setTextSize(14); t.setGravity(Gravity.RIGHT);
        return t;
    }

    static Button action(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s); b.setTextColor(TEXT); b.setTextSize(15); b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(primary ? BLUE : SURFACE, 18, c));
        b.setPadding(dp(c,12), dp(c,10), dp(c,12), dp(c,10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(c,58), 1f);
        lp.setMargins(dp(c,5), dp(c,5), dp(c,5), dp(c,5));
        b.setLayoutParams(lp);
        return b;
    }

    static View spacer(Context c, int h) {
        View v = new View(c); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c,h))); return v;
    }
}
