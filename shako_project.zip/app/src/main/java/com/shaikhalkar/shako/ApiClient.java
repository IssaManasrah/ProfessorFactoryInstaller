package com.shaikhalkar.shako;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ApiClient {
    // Current SHAKO API connected to shaikhalkar.com database.
    static final String BASE = "https://shaikhalkar.com/shako-api/api/";
    private static final ExecutorService IO = Executors.newCachedThreadPool();

    interface ProductsCallback {
        void success(List<ProductLite> products);
        void error(String message);
    }

    interface AiCallback {
        void success(String answer);
        void error(String message);
    }

    static final class ProductLite {
        final int id;
        final String name;
        final double price;
        final String currency;
        final boolean available;
        final String url;
        ProductLite(int id, String name, double price, String currency, boolean available, String url) {
            this.id=id; this.name=name; this.price=price; this.currency=currency; this.available=available; this.url=url;
        }
    }

    static void latestProducts(ProductsCallback callback) {
        IO.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(BASE + "products.php?limit=6");
                c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestMethod("GET");
                c.setRequestProperty("Accept", "application/json");
                int code = c.getResponseCode();
                String json = readAll(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                JSONObject root = new JSONObject(json);
                if (!root.optBoolean("ok", false)) throw new Exception(root.optString("error", "API returned ok=false"));
                JSONArray data = root.optJSONArray("items");
                if (data == null) data = root.optJSONArray("data");
                List<ProductLite> out = new ArrayList<>();
                if (data != null) for (int i=0;i<data.length();i++) {
                    JSONObject p = data.optJSONObject(i); if (p==null) continue;
                    out.add(new ProductLite(
                        p.optInt("id"), p.optString("name"), p.optDouble("price"),
                        p.optString("currency","JOD"), p.optBoolean("available"), p.optString("url")
                    ));
                }
                callback.success(out);
            } catch (Exception e) {
                callback.error(e.getMessage()==null ? "تعذر الاتصال" : e.getMessage());
            } finally { if (c != null) c.disconnect(); }
        });
    }

    static void askShako(String message, JSONArray history, String imageDataUrl, AiCallback callback) {
        IO.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(BASE + "assistant.php");
                c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(12000);
                c.setReadTimeout(70000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");

                JSONObject body = new JSONObject();
                body.put("message", message);
                body.put("history", history == null ? new JSONArray() : history);
                if (imageDataUrl != null && !imageDataUrl.isEmpty()) body.put("image_data_url", imageDataUrl);

                byte[] raw = body.toString().getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(raw.length);
                try (OutputStream os = c.getOutputStream()) { os.write(raw); }

                int code = c.getResponseCode();
                String json = readAll(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
                JSONObject root = new JSONObject(json);
                if (code < 200 || code >= 300 || !root.optBoolean("ok", false)) {
                    throw new Exception(root.optString("message", root.optString("error", "تعذر تشغيل مساعد شاكو")));
                }
                String answer = root.optString("answer", "").trim();
                if (answer.isEmpty()) throw new Exception("وصل رد فارغ من المساعد");
                callback.success(answer);
            } catch (Exception e) {
                callback.error(e.getMessage()==null ? "تعذر الاتصال بمساعد شاكو" : e.getMessage());
            } finally { if (c != null) c.disconnect(); }
        });
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line; while ((line=r.readLine())!=null) b.append(line);
        }
        return b.toString();
    }
}
