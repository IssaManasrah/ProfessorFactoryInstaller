package com.shaikhalkar.shako;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_MIC = 7101;
    private static final int REQ_IMAGE = 7102;
    private LinearLayout messages;
    private ScrollView scroll;
    private EditText input;
    private Button send;
    private Button mic;
    private Button photo;
    private ProgressBar thinking;
    private final JSONArray history = new JSONArray();
    private SpeechRecognizer speech;
    private TextToSpeech tts;
    private String pendingImageDataUrl;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        tts = new TextToSpeech(this, this);
        buildUi();
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Ui.BG);
        page.setPadding(Ui.dp(this,16),Ui.dp(this,14),Ui.dp(this,16),Ui.dp(this,12));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=Ui.title(this,"شاكو",26);
        title.setTextColor(Ui.GOLD);
        top.addView(title, new LinearLayout.LayoutParams(0,-2,1f));
        TextView live = Ui.body(this,"● متصل");
        live.setTextColor(Ui.BLUE);
        top.addView(live);
        page.addView(top);

        TextView hint=Ui.body(this,"أنا شاكو، مساعدك الذكي. اسألني أو احكيلي أو ابعتلي صورة.");
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=Ui.dp(this,5); hint.setLayoutParams(hp); page.addView(hint);

        scroll=new ScrollView(this);
        messages=new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setGravity(Gravity.RIGHT);
        scroll.addView(messages);
        LinearLayout.LayoutParams svp=new LinearLayout.LayoutParams(-1,0,1f);
        svp.topMargin=Ui.dp(this,12); scroll.setLayoutParams(svp); page.addView(scroll);

        addBot("أهلًا 👋 أنا شاكو. احكيلي شو بدك، أو اضغط المايك واحكي، أو ابعتلي صورة للمشكلة.", false);
        addQuickActions();

        thinking = new ProgressBar(this);
        thinking.setIndeterminate(true);
        thinking.setVisibility(View.GONE);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(Ui.dp(this,28), Ui.dp(this,28));
        tp.gravity = Gravity.RIGHT; tp.setMargins(0,5,5,5); thinking.setLayoutParams(tp);
        page.addView(thinking);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        mic=Ui.action(this,"🎙 صوت",false);
        photo=Ui.action(this,"📷 صورة",false);
        tools.addView(mic); tools.addView(photo); page.addView(tools);

        LinearLayout composer=new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        input=new EditText(this);
        input.setHint("اكتب لِشاكو..."); input.setHintTextColor(Ui.MUTED); input.setTextColor(Ui.TEXT);
        input.setSingleLine(true); input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setBackground(Ui.rounded(Ui.SURFACE,18,this));
        input.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,Ui.dp(this,56),1f);
        ip.setMargins(Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5)); input.setLayoutParams(ip);
        send=Ui.action(this,"إرسال",true);
        composer.addView(input); composer.addView(send); page.addView(composer);

        Runnable submit=()->submitMessage(input.getText().toString().trim());
        send.setOnClickListener(v->submit.run());
        input.setOnEditorActionListener((v,a,e)->{ if(a==EditorInfo.IME_ACTION_SEND){submit.run();return true;}return false;});
        mic.setOnClickListener(v->startVoice());
        photo.setOnClickListener(v->pickImage());
        setContentView(page);
    }

    private void addQuickActions() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button a=Ui.action(this,"اسأل شاكو",false);
        Button b=Ui.action(this,"عندي مشكلة",false);
        a.setOnClickListener(v->submitMessage("ساعدني في سؤالي خطوة بخطوة"));
        b.setOnClickListener(v->submitMessage("عندي مشكلة بجهاز وبدي منك تشخّصها معي خطوة بخطوة"));
        row.addView(a); row.addView(b); messages.addView(row);
    }

    private void submitMessage(String q) {
        if (q.isEmpty() && pendingImageDataUrl == null) return;
        String display = q.isEmpty() ? "📷 صورة مرفقة" : q + (pendingImageDataUrl != null ? "  📷" : "");
        addUser(display);
        input.setText("");
        setBusy(true);
        JSONArray compactHistory = new JSONArray();
        int start = Math.max(0, history.length() - 10);
        for (int i=start;i<history.length();i++) compactHistory.put(history.opt(i));
        String image = pendingImageDataUrl;
        pendingImageDataUrl = null;
        String message = q.isEmpty() ? "حلّل الصورة وساعدني بناءً على ما يظهر فيها." : q;

        ApiClient.askShako(message, compactHistory, image, new ApiClient.AiCallback() {
            @Override public void success(String answer) {
                runOnUiThread(() -> {
                    setBusy(false);
                    remember("user", message);
                    remember("assistant", answer);
                    addBot(answer, true);
                });
            }
            @Override public void error(String message) {
                runOnUiThread(() -> {
                    setBusy(false);
                    addBot("ما قدرت أوصل لخدمة الذكاء الاصطناعي الآن. " + message, false);
                });
            }
        });
    }

    private void remember(String role, String text) {
        try { JSONObject x = new JSONObject(); x.put("role", role); x.put("content", text); history.put(x); }
        catch (Exception ignored) {}
    }

    private void setBusy(boolean b) {
        thinking.setVisibility(b ? View.VISIBLE : View.GONE);
        send.setEnabled(!b); mic.setEnabled(!b); photo.setEnabled(!b); input.setEnabled(!b);
    }

    private void addUser(String s){ addMsg("أنت\n"+s, Ui.BLUE); }
    private void addBot(String s, boolean speak){ addMsg("شاكو\n"+s, Ui.SURFACE); if(speak) speak(s); }
    private void addMsg(String s,int color){
        TextView t=Ui.body(this,s); t.setTextColor(Ui.TEXT); t.setTextSize(15);
        t.setPadding(Ui.dp(this,14),Ui.dp(this,12),Ui.dp(this,14),Ui.dp(this,12));
        t.setBackground(Ui.rounded(color,16,this));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,Ui.dp(this,6),0,Ui.dp(this,6)); t.setLayoutParams(p);
        messages.addView(t); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this,"التعرّف الصوتي غير متاح على هذا الجهاز",Toast.LENGTH_SHORT).show(); return; }
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        if (speech != null) speech.destroy();
        speech = SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params){ mic.setText("🎙 اسمعك..."); }
            @Override public void onBeginningOfSpeech(){}
            @Override public void onRmsChanged(float rmsdB){}
            @Override public void onBufferReceived(byte[] buffer){}
            @Override public void onEndOfSpeech(){ mic.setText("🎙 صوت"); }
            @Override public void onError(int error){ mic.setText("🎙 صوت"); Toast.makeText(MainActivity.this,"جرّب تحكي مرة ثانية",Toast.LENGTH_SHORT).show(); }
            @Override public void onResults(Bundle results){
                mic.setText("🎙 صوت");
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(list!=null && !list.isEmpty()){ input.setText(list.get(0)); submitMessage(list.get(0)); }
            }
            @Override public void onPartialResults(Bundle partialResults){}
            @Override public void onEvent(int eventType, Bundle params){}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        speech.startListening(i);
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        startActivityForResult(Intent.createChooser(i,"اختر صورة لِشاكو"), REQ_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_IMAGE && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            try {
                Uri uri=data.getData();
                InputStream in=getContentResolver().openInputStream(uri);
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                byte[] buf=new byte[8192]; int n; int total=0; final int max=3*1024*1024;
                while((n=in.read(buf))>0 && total<max){ int take=Math.min(n,max-total); out.write(buf,0,take); total+=take; }
                if(in!=null) in.close();
                String mime=getContentResolver().getType(uri); if(mime==null || !mime.startsWith("image/")) mime="image/jpeg";
                pendingImageDataUrl="data:"+mime+";base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
                photo.setText("📷 جاهزة ✓");
                Toast.makeText(this,"الصورة جاهزة، اكتب سؤالك أو اضغط إرسال",Toast.LENGTH_SHORT).show();
            } catch(Exception e){ Toast.makeText(this,"تعذر قراءة الصورة",Toast.LENGTH_SHORT).show(); }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQ_MIC && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) startVoice();
    }

    @Override public void onInit(int status) {
        if(status==TextToSpeech.SUCCESS){ int r=tts.setLanguage(new Locale("ar","JO")); if(r<0) tts.setLanguage(new Locale("ar")); }
    }
    private void speak(String s) { if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"shako_reply"); }

    @Override protected void onDestroy(){
        if(speech!=null) speech.destroy();
        if(tts!=null){ tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
